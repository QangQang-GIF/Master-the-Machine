MTM PLAYER
Open mtm-player.exe without arguments. Select the team workspace on Manage or Init. See app/docs/installation.md for setup instructions.
Requires Windows, PowerShell 7, and a supported authenticated CLI provider.
Node.js is bundled. Codex desktop and an MTM Player plugin are not required.
